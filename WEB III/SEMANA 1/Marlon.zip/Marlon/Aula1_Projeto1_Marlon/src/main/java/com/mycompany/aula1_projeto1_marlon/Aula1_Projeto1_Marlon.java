/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aula1_projeto1_marlon;

/**
 *
 * @author QI
 */
public class Aula1_Projeto1_Marlon {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
